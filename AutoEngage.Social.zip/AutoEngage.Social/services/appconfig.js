(function(){
  var app = angular.module('appConfig', []);
    app.value('config', {
        debuggMode : true
    });
})();